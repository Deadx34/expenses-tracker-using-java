package com.s22010250.myexpensetracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

// create database
public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME ="expense.db";
// define Table
    public static final String TABLE_NAME ="expense_table";
// define columns
    public static final String COL_1 = "ID";
    public static final String COL_2 = "AMOUNT";
    public static final String COL_3 = "DATE";
    public static final String COL_4 = "TYPE";
// ----------------------------------------------------------->
    public DataBaseHelper(Context context) {
        super(context,DATABASE_NAME, null, 1);
//        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+TABLE_NAME+" (ID INTEGER PRIMARY KEY AUTOINCREMeNT," + "AMOUNT REAL, DATE INTEGER, TYPE TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop Table IF EXISTS " + TABLE_NAME);

    }

// Insert data to the table----------------------------------------------------->
    public boolean insertData(String AMOUNT, String TYPE){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,AMOUNT);
        contentValues.put(COL_3, getCurrentDateTime());
        contentValues.put(COL_4,TYPE);

// initialize data row
        long result = db.insert(TABLE_NAME, null, contentValues);

// check table content
        return result != -1;
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from expense_table",null);
        return cursor;
    }

    public int deleteData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COL_1 + "=?", new String[]{id});
    }

    private String getCurrentDateTime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return simpleDateFormat.format(new Date());
    }

}
