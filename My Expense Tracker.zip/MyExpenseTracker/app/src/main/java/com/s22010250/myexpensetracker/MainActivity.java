package com.s22010250.myexpensetracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    DataBaseHelper expensesDb;
    EditText editTextAmount, editTextType, editTextId;
    Button btnSave, Delete, btnViewExpenses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//  New DatabaseHelper Instance
        expensesDb = new DataBaseHelper(this);

//text views
        editTextAmount = findViewById(R.id.editTextAmount);
        editTextType = findViewById(R.id.editTextType);
        editTextId = findViewById(R.id.editTextId);

//buttons
        btnSave = findViewById(R.id.btnSave);
        Delete = findViewById(R.id.btnDelete);
        btnViewExpenses = findViewById(R.id.btnViewExpenses);
        insertData();
    }

    // methods---------------------------------------------->
    public void insertData() {
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isDataInserted = expensesDb.insertData(editTextAmount.getText().toString(), editTextType.getText().toString());

                if (isDataInserted){
                    Toast.makeText(MainActivity.this, "Data Inserted successfully", Toast.LENGTH_LONG).show();
                editTextAmount.getText().clear();
                editTextType.getText().clear();
            }else {
                    Toast.makeText(MainActivity.this, "Data Inserted unsuccessful", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // set click listener for Delete button
        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteData();
            }

            // Method to delete data from the database
            public void deleteData () {
                // Get ID from EditText
                String id = editTextId.getText().toString();

                // Call deleteData method of DataBaseHelper
                int deletedRows = expensesDb.deleteData(id);

                // Show Toast message based on deletion result
                if (deletedRows > 0) {
                    Toast.makeText(MainActivity.this, "Data deleted successfully", Toast.LENGTH_SHORT).show();
                    editTextId.getText().clear();
                } else {
                    Toast.makeText(MainActivity.this, "Failed to delete data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set click listener for View Expenses button
        btnViewExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewExpenses();
            }
        });
// method to view database
        btnViewExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = expensesDb.getData();
                if (res.getCount()==0){
                    Toast.makeText(MainActivity.this, "No Data Found", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuilder buffer = new StringBuilder();
                while (res.moveToNext()){
                    buffer.append("Expense Number: ").append(res.getString(0)).append("\n");
                    buffer.append("Amount Rs: ").append(res.getString(1)).append("\n");
                    buffer.append("Date: ").append(res.getString(2)).append("\n");
                    buffer.append("Type: ").append(res.getString(3)).append("\n");
                    buffer.append("______________________________"+"\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("MY EXPENSES");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }

// Method to start ExpensesActivity
    public void viewExpenses() {
        Intent intent = new Intent(MainActivity.this, ExpensesActivity.class);
        startActivity(intent);

    }
}